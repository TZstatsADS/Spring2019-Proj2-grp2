# Project 2: Open Data App - an RShiny app development project

### 

This folder contains all the school logo images used in tab2 (Compare two schools). 


